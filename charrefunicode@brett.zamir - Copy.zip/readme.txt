The extension itself contains notes and instructions on help.

See goals.txt for some possible future ideas.

Volunteers to help in translation or expansion of the code, 
etc., are most welcome, as is any feedback.

Acknowledgments:

     Thanks to Jordan M. Marshall for his extension, 
ASCIItoUnicode:
	https://addons.mozilla.org/en-US/firefox/addon/1313
which I considered in the beginning of my work on 
this project.

     Thanks to Ted Mielczarek for the the Extension Wizard at
http://ted.mielczarek.org/code/mozilla/extensionwiz/ which 
allowed me to really get going on my own extensions as
I for one certainly prefer to spend what time I do have 
on programming rather than performing set up!

	Many thanks to my hard-working translators, Karoly Fabricz and Edgard Dias Magalhães! 
Not many extensions where the translation may be comparable or harder in difficulty 
making the extension itself! I just had to copy the language names and categories...
	Much appreciation also to the maintainers of Babelzilla for greatly facilitating localization.
     And of course many thanks to all of the excellent volunteers and 
workers who make Firefox what it is!

Donations: 

     Please consider a Paypal donation if you like this extension:

https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&amp;business=brettz9%40yahoo%2ecom&amp;no_shipping=0&amp;no_note=1&amp;tax=0&amp;currency_code=USD&amp;bn=PP%2dDonationsBF&amp;charset=UTF%2d8

Hopefully, this extension will save you some work in 
finding the characters you need and perfoming conversions.

best wishes,
Brett Zamir
brettz9 at the well-known yahoo dot com address
